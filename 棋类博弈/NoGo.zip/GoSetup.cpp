#include "pch.h"
#include "GoSetup.h"
#include "go.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// CGoSetup ���

CGoSetup::CGoSetup(CWnd* pParent /*=NULL*/)
    : CDialog(CGoSetup::IDD, pParent)
{
    m_boardsize = 0;
    m_black = 0;
}

//�����½���Ϸ�Ի���
void CGoSetup::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_CBIndex(pDX, IDC_COMBO2, m_black);
}

BEGIN_MESSAGE_MAP(CGoSetup, CDialog)
    ON_BN_CLICKED(IDOK, &CGoSetup::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGoSetup ��Ϣ��������

BOOL CGoSetup::DestroyWindow()
{
    // TODO: Add your specialized code here and/or call the base class
    UpdateData(true);
    return CDialog::DestroyWindow();
}

void CGoSetup::OnBnClickedOk()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    CDialog::OnOK();
}
