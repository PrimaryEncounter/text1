#pragma once
#include "resource.h"

//CGoSetup��
class CGoSetup : public CDialog
{
public:
    CGoSetup(CWnd* pParent = NULL); // standard constructor
    enum
    {
        IDD = IDD_SETUP_DIALOG
    };
    int m_boardsize;
    int m_black;

    // ��д
public:
    virtual BOOL DestroyWindow();

protected:
    virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support
                                                     //}}AFX_VIRTUAL
    // ʵ��

    // ���ɵ���Ϣӳ�亯��
protected:
    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
};
