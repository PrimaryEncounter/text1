﻿// GoView.h: CGoView 类的接口
//

#pragma once
#include "Function.h"

class CGoView : public CView
{
protected: // 仅从序列化创建
    CGoView() noexcept;
    DECLARE_DYNCREATE(CGoView)

    // 特性
public:
    CGoDoc* GetDocument() const;
    void DrawStone(int d, CDC* pWhiteStoneDC, CDC* pBlackStoneDC);
    // 操作
public:
    int boardwidth{}, d{};
    int blackplayer{};
    Function game{};
    COLORREF boardcolor{};
    BOOL GameSetup{};
    CRect rcWindow, rcBoard;
    // 重写
public:
    virtual void OnDraw(CDC* pDC);                      //用于绘制棋盘和棋子
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual void OnInitialUpdate();                     //起始设置

protected:
    virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
    virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
    virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
    // 实现
public:
    virtual ~CGoView();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    // 生成的消息映射函数
protected:
    afx_msg void OnFilePrintPreview();
    afx_msg void OnFileNew();                                   //创建新游戏
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);      //用来处理鼠标左键点下的操作
    afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
    DECLARE_MESSAGE_MAP()
public:
    void Regret();                                              //悔棋
};

#ifndef _DEBUG // GoView.cpp 中的调试版本
inline CGoDoc* CGoView::GetDocument() const
{
    return reinterpret_cast<CGoDoc*>(m_pDocument);
}
#endif
